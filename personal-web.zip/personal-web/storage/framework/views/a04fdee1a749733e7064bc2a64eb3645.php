<!DOCTYPE html>
<html>

<head>
    <title>Message from <?php echo e($details['name']); ?></title>
</head>

<body>
    <h2>You have received a new message from <?php echo e($details['name']); ?></h2>
    <p><strong>Name:</strong> <?php echo e($details['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($details['email']); ?></p>
    <p><strong>Message:</strong> <?php echo e($details['message']); ?></p>
</body>

</html><?php /**PATH C:\Users\ZAEDAR GHAZALBA\Desktop\SUPERWEB\personal-web\resources\views/sendmail.blade.php ENDPATH**/ ?>